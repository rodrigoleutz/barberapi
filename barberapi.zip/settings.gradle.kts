rootProject.name = "com.example.barberapi"
